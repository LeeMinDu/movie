import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/services.dart';
import 'package:movie/models/actor.dart';
import 'package:movie/models/category.dart';
import 'package:movie/models/movie.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppRepository {
  const AppRepository._();

  static final _shelf = <String, dynamic>{};
  static final _db = FirebaseFirestore.instance;
  static late final SharedPreferences _preferences;
  static late final Map<String, String> _localizations;

  static const _actor = 'actor';
  static const _movie = 'movie';
  static const _category = 'category';

  static const _theme = 'theme';
  static const _language = 'language';

  static Future<void> initialise() async {
    _preferences = await SharedPreferences.getInstance();
    _localizations = Map.from(
      jsonDecode(
        await rootBundle.loadString(
          'assets/locales/${await getLanguage() ? 'vi' : 'en'}.json',
        ),
      ),
    );
  }

  static String translate(int id) => _localizations['$id'] ?? '$id';

  static Future<Iterable<Actor>> getAllActors() async {
    if (_shelf.containsKey(_actor)) return _shelf[_actor];
    final query = await _db
        .collection(_actor)
        .withConverter(
          fromFirestore: (snapshot, _) => Actor.fromJson(
            snapshot.id,
            snapshot.data()!,
          ),
          toFirestore: (value, options) => value.toJson(),
        )
        .get();
    return _shelf[_actor] = query.docs.map((doc) => doc.data());
  }

  static Future<Iterable<Movie>> getAllMovies() async {
    if (_shelf.containsKey(_movie)) return _shelf[_movie];
    final query = await _db
        .collection(_movie)
        .withConverter(
          fromFirestore: (snapshot, _) => Movie.fromJson(
            snapshot.id,
            snapshot.data()!,
          ),
          toFirestore: (value, options) => value.toJson(),
        )
        .get();
    return _shelf[_movie] = query.docs.map((doc) => doc.data());
  }

  static Future<Iterable<Category>> getAllCategories() async {
    if (_shelf.containsKey(_category)) return _shelf[_category];
    final query = await _db
        .collection(_category)
        .withConverter(
          fromFirestore: (snapshot, _) => Category.fromJson(
            snapshot.id,
            snapshot.data()!,
          ),
          toFirestore: (value, options) => value.toJson(),
        )
        .get();
    return _shelf[_category] = query.docs.map((doc) => doc.data());
  }

  static Future<Iterable<Movie>> getFavoriteMovies() async {
    final movieIds = _preferences.getStringList(_movie) ?? [];
    if (movieIds.isEmpty) return [];
    final movies = await getAllMovies();
    return movies.where((movie) => movieIds.contains(movie.id));
  }

  static Future<bool> setFavoriteMovies(Iterable<Movie> movies) async {
    final movieIds = movies.map((e) => e.id).toList();
    return _preferences.setStringList(_movie, movieIds);
  }

  static Future<Iterable<Actor>> getFavoriteActors() async {
    final actorIds = _preferences.getStringList(_actor) ?? [];
    if (actorIds.isEmpty) return [];
    final actors = await getAllActors();
    return actors.where((actor) => actorIds.contains(actor.id));
  }

  static Future<bool> setFavoriteActors(Iterable<Actor> actors) async {
    final actorIds = actors.map((e) => e.id).toList();
    return _preferences.setStringList(_actor, actorIds);
  }

  static Future<bool> getLanguage() async {
    return _preferences.getBool(_language) ?? true;
  }

  static Future<bool> getTheme() async {
    return _preferences.getBool(_theme) ?? true;
  }

  static Future<bool> setTheme(bool theme) async {
    return _preferences.setBool(_theme, theme);
  }

  static Future<bool> setLanguage(bool language) async {
    return _preferences.setBool(_language, language);
  }
}
