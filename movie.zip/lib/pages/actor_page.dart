import 'dart:math';

import 'package:flutter/material.dart';
import 'package:movie/app/repository.dart';
import 'package:movie/models/actor.dart';

class ActorPage extends StatelessWidget {
  const ActorPage(this.actor, {super.key});

  final Actor actor;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) {
          return [
            SliverAppBar(
              pinned: true,
              backgroundColor: Colors.transparent,
              leading: IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const CircleAvatar(
                  backgroundColor: Color(0x44000000),
                  child: Icon(Icons.arrow_back, color: Colors.white),
                ),
              ),
              expandedHeight: MediaQuery.of(context).size.height / 1.6,
              flexibleSpace: FlexibleSpaceBar(
                background: Image.network(
                  actor.images.first,
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ];
        },
        body: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(
            vertical: 8,
            horizontal: 16,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Column(
                children: [
                  Text(
                    actor.name,
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 28),
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text('Diễn viên'),
                  ),
                ],
              ),
              Text(
                'Tiểu sử',
                style: Theme.of(context).textTheme.headline6,
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Text(actor.bio),
              ),
              Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text(
                        'Thông tin',
                        style: Theme.of(context).textTheme.headline6,
                      ),
                    ),
                    Text(
                      'Giới tính: ${actor.gender ? 'Nam' : 'Nữ'}',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    Text(
                      'Ngày sinh: ${actor.birthday}',
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              Text(
                'Ảnh',
                style: Theme.of(context).textTheme.headline6,
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 3,
                child: ListView.separated(
                  padding: const EdgeInsets.all(8),
                  scrollDirection: Axis.horizontal,
                  itemCount: actor.images.length,
                  itemBuilder: (context, index) {
                    return Image.network(
                      actor.images.elementAt(index),
                    );
                  },
                  separatorBuilder: (context, index) => const SizedBox(width: 8),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8).copyWith(bottom: 16),
                    child: Text(
                      AppRepository.translate(24),
                      style: Theme.of(context).textTheme.headline6,
                    ),
                  ),
                  FutureBuilder(
                    future: actor.getMovies(),
                    builder: (context, snapshot) {
                      if (snapshot.hasData) {
                        final movies = snapshot.requireData.toList();
                        return SizedBox(
                          height: MediaQuery.of(context).size.height / 2.2,
                          child: ListView.separated(
                            scrollDirection: Axis.horizontal,
                            padding: const EdgeInsets.all(8).copyWith(top: 0),
                            itemCount: movies.length,
                            itemBuilder: (context, index) {
                              final movie = movies.elementAt(index);
                              final rating = Random.secure().nextDouble();

                              return InkWell(
                                child: SizedBox(
                                  width: MediaQuery.of(context).size.width / 3,
                                  child: Column(
                                    children: [
                                      Stack(
                                        children: [
                                          Image.network(
                                            movie.images.first,
                                          ),
                                          Positioned(
                                            left: 8,
                                            bottom: 8,
                                            child: CircleAvatar(
                                              child: Center(
                                                child: Stack(
                                                  alignment: Alignment.center,
                                                  children: [
                                                    Text((rating * 100).toStringAsFixed(0)),
                                                    CircularProgressIndicator(
                                                      value: rating,
                                                      color: rating >= 0.5 ? Colors.greenAccent : Colors.yellow,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                      ListTile(
                                        title: Text(
                                          movie.name,
                                          maxLines: 2,
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                        subtitle: Text(
                                          '${movie.year}',
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
                              );
                            },
                            separatorBuilder: (context, index) => const SizedBox(width: 8),
                          ),
                        );
                      }
                      return const SizedBox.shrink();
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
