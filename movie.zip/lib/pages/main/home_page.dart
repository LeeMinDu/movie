// ignore_for_file: use_build_context_synchronously

part of 'main_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  static const moviesMaxCount = 10;

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).colorScheme.primary;
    final secondaryColor = Theme.of(context).colorScheme.onPrimary;
    return Scaffold(
      backgroundColor: primaryColor,
      appBar: AppBar(
        title: Text(
          AppRepository.translate(1),
        ),
      ),
      body: FutureBuilder(
        future: AppRepository.getAllMovies(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            final recommendMovies = snapshot.requireData.toList()
              ..shuffle()
              ..take(moviesMaxCount);
            final newestMovies = snapshot.requireData.toList()
              ..sort((a, b) {
                return a.year.compareTo(b.year);
              })
              ..take(moviesMaxCount);
            final topMovies = snapshot.requireData.toList()
              ..sort((a, b) {
                final x = a.revenue;
                final y = b.revenue;
                return x.compareTo(y);
              })
              ..take(moviesMaxCount)
              ..reversed;
            return ListView(
              children: [
                // Logo
                Image.network(
                  'https://pbs.twimg.com/profile_images/1243623122089041920/gVZIvphd_400x400.jpg',
                  fit: BoxFit.cover,
                ),
                // Recommend
                Container(
                  margin: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(
                    color: secondaryColor,
                    borderRadius: const BorderRadius.all(
                      Radius.circular(16),
                    ),
                  ),
                  child: Column(
                    children: [
                      ListTile(
                        minLeadingWidth: 0,
                        title: Text(
                          AppRepository.translate(5),
                          style: TextStyle(
                            color: primaryColor,
                          ),
                        ),
                        leading: Icon(
                          Icons.recommend,
                          color: primaryColor,
                        ),
                        trailing: TextButton(
                          onPressed: () async {
                            Navigator.pushNamed(
                              context,
                              '/movie',
                              arguments: {
                                'title': AppRepository.translate(5),
                                'movies': recommendMovies,
                              },
                            );
                          },
                          child: Text(
                            AppRepository.translate(7),
                            style: TextStyle(
                              color: primaryColor,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height / 2.2,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          padding: const EdgeInsets.all(8).copyWith(top: 0),
                          itemCount: recommendMovies.length,
                          itemBuilder: (context, index) {
                            final movie = recommendMovies.elementAt(index);
                            final rating = Random.secure().nextDouble();

                            return InkWell(
                              child: SizedBox(
                                width: MediaQuery.of(context).size.width / 3,
                                child: Column(
                                  children: [
                                    Stack(
                                      children: [
                                        Image.network(
                                          movie.images.first,
                                        ),
                                        Positioned(
                                          left: 8,
                                          bottom: 8,
                                          child: CircleAvatar(
                                            child: Center(
                                              child: Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  Text((rating * 100).toStringAsFixed(0)),
                                                  CircularProgressIndicator(
                                                    value: rating,
                                                    color: rating >= 0.5 ? Colors.greenAccent : Colors.yellow,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    ListTile(
                                      title: Text(
                                        movie.name,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(
                                          color: primaryColor,
                                        ),
                                      ),
                                      subtitle: Text(
                                        '${movie.year}',
                                        style: TextStyle(
                                          color: primaryColor,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
                            );
                          },
                          separatorBuilder: (context, index) => const SizedBox(width: 8),
                        ),
                      ),
                    ],
                  ),
                ),
                // Newest
                Column(
                  children: [
                    ListTile(
                      selected: true,
                      selectedColor: secondaryColor,
                      minLeadingWidth: 0,
                      title: Text(
                        AppRepository.translate(6),
                      ),
                      leading: const Icon(Icons.new_label),
                      trailing: TextButton(
                        onPressed: () async {
                          await Navigator.pushNamed(
                            context,
                            '/movie',
                            arguments: {
                              'title': AppRepository.translate(6),
                              'movies': newestMovies,
                            },
                          );
                        },
                        child: Text(
                          AppRepository.translate(7),
                          style: TextStyle(color: secondaryColor),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height / 2.2,
                      child: ListView.separated(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.all(8).copyWith(top: 0),
                        itemCount: newestMovies.length,
                        itemBuilder: (context, index) {
                          final movie = newestMovies.elementAt(index);
                          final rating = Random.secure().nextDouble();
                          return InkWell(
                            child: SizedBox(
                              width: MediaQuery.of(context).size.width / 3,
                              child: Column(
                                children: [
                                  Stack(
                                    children: [
                                      Image.network(
                                        movie.images.first,
                                      ),
                                      Positioned(
                                        left: 8,
                                        bottom: 8,
                                        child: CircleAvatar(
                                          child: Center(
                                            child: Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Text((rating * 100).toStringAsFixed(0)),
                                                CircularProgressIndicator(
                                                  value: rating,
                                                  color: Colors.greenAccent,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  ListTile(
                                    title: Text(
                                      movie.name,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(color: secondaryColor),
                                    ),
                                    subtitle: Text(
                                      '${movie.year}',
                                      style: const TextStyle(color: Colors.grey),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
                          );
                        },
                        separatorBuilder: (context, index) => const SizedBox(width: 8),
                      ),
                    ),
                  ],
                ),
                // Top-rated
                Container(
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.all(
                      Radius.circular(16),
                    ),
                    image: DecorationImage(
                      fit: BoxFit.cover,
                      image: NetworkImage(
                        'https://e.khoahoc.tv/photos/image/2015/12/15/anh-dep-mua-dong-21.jpg',
                      ),
                    ),
                  ),
                  child: Column(
                    children: [
                      ListTile(
                        selected: true,
                        selectedColor: secondaryColor,
                        minLeadingWidth: 0,
                        title: Text(
                          AppRepository.translate(16),
                        ),
                        leading: const Icon(Icons.tour),
                        trailing: TextButton(
                          onPressed: () async {
                            Navigator.pushNamed(
                              context,
                              '/movie',
                              arguments: {
                                'title': AppRepository.translate(16),
                                'movies': topMovies,
                              },
                            );
                          },
                          child: Text(
                            AppRepository.translate(7),
                            style: TextStyle(color: secondaryColor),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: MediaQuery.of(context).size.height / 2.2,
                        child: ListView.separated(
                          scrollDirection: Axis.horizontal,
                          padding: const EdgeInsets.all(8).copyWith(top: 0),
                          itemCount: topMovies.length,
                          itemBuilder: (context, index) {
                            final movie = topMovies.elementAt(index);
                            final rating = Random.secure().nextDouble();

                            return InkWell(
                              child: SizedBox(
                                width: MediaQuery.of(context).size.width / 3,
                                child: Column(
                                  children: [
                                    Stack(
                                      children: [
                                        Image.network(
                                          movie.images.first,
                                        ),
                                        Positioned(
                                          left: 8,
                                          bottom: 8,
                                          child: CircleAvatar(
                                            child: Center(
                                              child: Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  Text((rating * 100).toStringAsFixed(0)),
                                                  CircularProgressIndicator(
                                                    value: rating,
                                                    color: rating >= 0.5 ? Colors.greenAccent : Colors.yellow,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    ListTile(
                                      title: Text(
                                        movie.name,
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                        style: TextStyle(color: secondaryColor),
                                      ),
                                      subtitle: Text(
                                        '${movie.year}',
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
                            );
                          },
                          separatorBuilder: (context, index) => const SizedBox(width: 8),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }
}
