import 'dart:math';

import 'package:flutter/material.dart';
import 'package:movie/app/repository.dart';

part 'favorite_page.dart';
part 'home_page.dart';
part 'search_page.dart';
part 'settings_page.dart';

class MainPage extends StatelessWidget {
  const MainPage({super.key});

  @override
  Widget build(BuildContext context) {
    var pageIndex = 0;
    final pageEntries = {
      BottomNavigationBarItem(
        icon: const Icon(Icons.home),
        label: AppRepository.translate(1),
      ): const HomePage(),
      BottomNavigationBarItem(
        icon: const Icon(Icons.search),
        label: AppRepository.translate(2),
      ): const SearchPage(),
      BottomNavigationBarItem(
        icon: const Icon(Icons.favorite),
        label: AppRepository.translate(3),
      ): const FavoritePage(),
      BottomNavigationBarItem(
        icon: const Icon(Icons.settings),
        label: AppRepository.translate(4),
      ): const SettingsPage(),
    };
    final primaryColor = Theme.of(context).colorScheme.primary;
    final secondaryColor = Theme.of(context).colorScheme.onPrimary;
    return StatefulBuilder(
      builder: (context, setState) {
        return Scaffold(
          bottomNavigationBar: BottomNavigationBar(
            backgroundColor: primaryColor,
            selectedItemColor: secondaryColor,
            unselectedItemColor: secondaryColor,
            showUnselectedLabels: false,
            type: BottomNavigationBarType.fixed,
            currentIndex: pageIndex,
            items: pageEntries.keys.toList(),
            landscapeLayout: BottomNavigationBarLandscapeLayout.centered,
            onTap: (value) => setState(() => pageIndex = value),
          ),
          body: pageEntries.values.elementAt(pageIndex),
        );
      },
    );
  }
}
