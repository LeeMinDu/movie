part of 'main_page.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppRepository.translate(4),
        ),
      ),
      body: ListView(
        children: [
          StatefulBuilder(
            builder: (context, setState) {
              return FutureBuilder(
                future: AppRepository.getTheme(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    final theme = snapshot.requireData;
                    return SwitchListTile(
                      value: theme,
                      onChanged: (value) async {
                        await AppRepository.setTheme(value);
                        setState(() {});
                      },
                      title: Text(
                        AppRepository.translate(8),
                      ),
                      subtitle: Text(
                        theme ? AppRepository.translate(9) : AppRepository.translate(10),
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                },
              );
            },
          ),
          StatefulBuilder(
            builder: (context, setState) {
              return FutureBuilder(
                future: AppRepository.getLanguage(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    final language = snapshot.requireData;
                    return SwitchListTile(
                      value: snapshot.requireData,
                      onChanged: (value) async {
                        await AppRepository.setLanguage(value);
                        setState(() {});
                      },
                      title: Text(
                        AppRepository.translate(11),
                      ),
                      subtitle: Text(language ? 'Tiếng Việt' : 'English'),
                    );
                  }
                  return const SizedBox.shrink();
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
