part of 'main_page.dart';

class SearchPage extends StatelessWidget {
  const SearchPage({super.key});

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).colorScheme.primary;
    final secondaryColor = Theme.of(context).colorScheme.onPrimary;
    var submitted = false;
    final textController = TextEditingController();
    return StatefulBuilder(
      builder: (context, setState) {
        return Scaffold(
          appBar: AppBar(
            title: Container(
              decoration: BoxDecoration(
                color: secondaryColor,
                borderRadius: const BorderRadius.all(
                  Radius.circular(16),
                ),
              ),
              child: TextField(
                style: TextStyle(color: primaryColor),
                controller: textController
                  ..addListener(() {
                    setState(() {
                      if (textController.text.isEmpty) submitted = false;
                    });
                  }),
                decoration: InputDecoration(
                  prefixIcon: Icon(
                    Icons.search,
                    color: primaryColor,
                  ),
                  hintText: AppRepository.translate(12),
                  suffixIcon: Visibility(
                    visible: textController.text.isNotEmpty,
                    child: IconButton(
                      onPressed: () {
                        submitted = false;
                        textController.clear();
                      },
                      icon: Icon(
                        Icons.close,
                        color: primaryColor,
                      ),
                    ),
                  ),
                ),
                onSubmitted: (value) => submitted = true,
              ),
            ),
          ),
          body: !submitted
              ? textController.text.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const FlutterLogo(size: 256),
                          Text(
                            AppRepository.translate(13),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ],
                      ),
                    )
                  : FutureBuilder(
                      future: AppRepository.getAllMovies(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          final movies = snapshot.requireData.where(
                            (movie) => movie.name.toLowerCase().contains(textController.text.toLowerCase()),
                          );
                          return movies.isEmpty
                              ? const SizedBox.shrink()
                              : ListView.separated(
                                  itemCount: movies.length,
                                  itemBuilder: (context, index) {
                                    final movie = movies.elementAt(index);
                                    return ListTile(
                                      title: Text(movie.name),
                                      onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
                                    );
                                  },
                                  separatorBuilder: (context, index) => const Padding(
                                    padding: EdgeInsets.symmetric(vertical: 4),
                                    child: Divider(thickness: 2),
                                  ),
                                );
                        }
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      },
                    )
              : textController.text.isEmpty
                  ? const SizedBox.shrink()
                  : FutureBuilder(
                      future: AppRepository.getAllMovies(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          final movies = snapshot.requireData.where(
                            (movie) => movie.name.toLowerCase().contains(textController.text.toLowerCase()),
                          );
                          return movies.isEmpty
                              ? Center(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        '${AppRepository.translate(14)} ${textController.text}',
                                        style: Theme.of(context).textTheme.titleMedium,
                                      ),
                                      const FlutterLogo(size: 256),
                                    ],
                                  ),
                                )
                              : ColoredBox(
                                  color: primaryColor,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Text(
                                          'Tìm thấy ${movies.length} kết quả phù hợp với "${textController.text}"',
                                          style: TextStyle(color: secondaryColor),
                                        ),
                                      ),
                                      Expanded(
                                        child: ListView.separated(
                                          itemCount: movies.length,
                                          itemBuilder: (context, index) {
                                            final movie = movies.elementAt(index);
                                            return InkWell(
                                              onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
                                              child: Padding(
                                                padding: const EdgeInsets.all(8.0),
                                                child: Row(
                                                  children: [
                                                    SizedBox(
                                                      width: MediaQuery.of(context).size.width / 3,
                                                      child: Image.network(movie.images.first),
                                                    ),
                                                    Expanded(
                                                      child: Padding(
                                                        padding: const EdgeInsets.all(8.0),
                                                        child: Column(
                                                          crossAxisAlignment: CrossAxisAlignment.start,
                                                          children: [
                                                            Text(
                                                              movie.name,
                                                              style: Theme.of(context).textTheme.labelLarge?.copyWith(color: secondaryColor),
                                                            ),
                                                            Padding(
                                                              padding: const EdgeInsets.symmetric(vertical: 4.0),
                                                              child: Text(
                                                                movie.year.toString(),
                                                                style: Theme.of(context).textTheme.caption?.copyWith(color: secondaryColor),
                                                              ),
                                                            ),
                                                            Text(
                                                              movie.overview,
                                                              maxLines: 5,
                                                              overflow: TextOverflow.ellipsis,
                                                              style: Theme.of(context).textTheme.bodyText2?.copyWith(color: secondaryColor),
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            );
                                          },
                                          separatorBuilder: (context, index) => const SizedBox(height: 4),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                        }
                        return const Center(
                          child: CircularProgressIndicator(),
                        );
                      },
                    ),
        );
      },
    );
  }
}
