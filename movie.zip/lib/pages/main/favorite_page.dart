part of 'main_page.dart';

class FavoritePage extends StatelessWidget {
  const FavoritePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          AppRepository.translate(3),
        ),
      ),
      body: StatefulBuilder(builder: (context, setState) {
        return FutureBuilder(
          future: AppRepository.getFavoriteMovies(),
          builder: (context, snapshot) {
            if (snapshot.hasData) {
              final movies = snapshot.requireData;
              return movies.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const FlutterLogo(size: 256),
                          Text(
                            AppRepository.translate(15),
                            style: Theme.of(context).textTheme.titleMedium,
                          ),
                        ],
                      ),
                    )
                  : GridView.count(
                      crossAxisCount: 3,
                      mainAxisSpacing: 3,
                      crossAxisSpacing: 3,
                      childAspectRatio: 1 / 3,
                      padding: const EdgeInsets.all(8),
                      children: movies.map((movie) {
                        return InkWell(
                          onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
                          child: Column(
                            children: [
                              Stack(
                                children: [
                                  Image.network(
                                    movie.images.first,
                                  ),
                                  Align(
                                    alignment: Alignment.topRight,
                                    child: IconButton(
                                      onPressed: () async {
                                        final movies = snapshot.requireData.toList();
                                        await AppRepository.setFavoriteMovies(
                                          movies.toList()..removeWhere((e) => e.id == movie.id),
                                        );
                                        setState(() {});
                                      },
                                      icon: CircleAvatar(
                                        backgroundColor: const Color(0x44000000),
                                        child: Icon(
                                          Icons.favorite,
                                          color: Theme.of(context).colorScheme.onPrimary,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              ListTile(
                                title: Text(
                                  movie.name,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                ),
                                subtitle: Text('${movie.year}'),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    );
            }
            return const Center(
              child: CircularProgressIndicator(),
            );
          },
        );
      }),
    );
  }
}
