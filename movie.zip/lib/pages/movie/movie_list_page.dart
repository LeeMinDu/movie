import 'package:flutter/material.dart';
import 'package:movie/models/movie.dart';

class MovieListPage extends StatelessWidget {
  const MovieListPage(
    this.movies, {
    super.key,
    required this.title,
  });

  final String title;
  final Iterable<Movie> movies;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: ListView.builder(
        itemCount: movies.length,
        itemBuilder: (context, index) {
          final movie = movies.elementAt(index);
          return InkWell(
            onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                children: [
                  SizedBox(
                    width: MediaQuery.of(context).size.width / 3,
                    child: Image.network(movie.images.first),
                  ),
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            movie.name,
                            style: Theme.of(context).textTheme.labelLarge,
                          ),
                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4.0),
                            child: Text(
                              movie.year.toString(),
                              style: Theme.of(context).textTheme.caption,
                            ),
                          ),
                          Text(
                            movie.overview,
                            maxLines: 5,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.bodyText2,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
