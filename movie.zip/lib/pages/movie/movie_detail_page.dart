import 'dart:math';

import 'package:flutter/material.dart';
import 'package:movie/app/repository.dart';
import 'package:movie/models/movie.dart';
import 'package:url_launcher/url_launcher.dart';

class MovieDetailPage extends StatelessWidget {
  const MovieDetailPage(this.movie, {super.key});

  final Movie movie;

  @override
  Widget build(BuildContext context) {
    final primaryColor = Theme.of(context).colorScheme.primary;
    final secondaryColor = Theme.of(context).colorScheme.onPrimary;
    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) {
          return [
            SliverAppBar(
              pinned: true,
              title: Text(movie.name),
              backgroundColor: const Color(0x44000000),
              expandedHeight: MediaQuery.of(context).size.height / 2,
              flexibleSpace: FlexibleSpaceBar(
                background: Image.network(
                  movie.images.first,
                  fit: BoxFit.cover,
                ),
              ),
              actions: [
                StatefulBuilder(
                  builder: (context, setState) {
                    return FutureBuilder(
                      future: AppRepository.getFavoriteMovies(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          final movies = snapshot.requireData.toList();
                          final saved = movies.any((element) => element.id == movie.id);
                          return IconButton(
                            onPressed: () async {
                              if (saved) {
                                await AppRepository.setFavoriteMovies(
                                  movies..removeWhere((e) => e.id == movie.id),
                                );
                              } else {
                                await AppRepository.setFavoriteMovies(
                                  movies..add(movie),
                                );
                              }
                              setState(() {});
                            },
                            icon: Icon(
                              saved ? Icons.favorite : Icons.favorite_border,
                            ),
                          );
                        }
                        return const SizedBox.shrink();
                      },
                    );
                  },
                ),
              ],
            ),
          ];
        },
        body: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            movie.name,
                            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontSize: 28),
                          ),
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.calendar_month),
                                Text('${movie.year}'),
                              ],
                            ),
                            Row(
                              children: [
                                const Icon(Icons.timelapse),
                                Text('${movie.time} phút'),
                              ],
                            ),
                            Row(
                              children: const [
                                Icon(Icons.language),
                                Text('en'),
                              ],
                            ),
                          ],
                        ),
                      ],
                    ),
                    FutureBuilder(
                      future: movie.getCategories(),
                      builder: (context, snapshot) {
                        if (snapshot.hasData) {
                          final categories = snapshot.requireData;
                          return Row(
                            children: categories.map((category) {
                              return Padding(
                                padding: const EdgeInsets.only(right: 4),
                                child: Chip(
                                  label: Text(category.name),
                                  labelStyle: TextStyle(color: secondaryColor),
                                  backgroundColor: primaryColor,
                                ),
                              );
                            }).toList(),
                          );
                        }
                        return const SizedBox.shrink();
                      },
                    ),
                    Row(
                      children: const [
                        Icon(
                          Icons.star,
                          color: Colors.blue,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.blue,
                        ),
                        Icon(
                          Icons.star,
                          color: Colors.blue,
                        ),
                        Icon(
                          Icons.star_border,
                          color: Colors.blue,
                        ),
                        Icon(
                          Icons.star_border,
                          color: Colors.blue,
                        ),
                        SizedBox(width: 4),
                        Text(
                          '1558 votes',
                          style: TextStyle(color: Colors.blue),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Giới thiệu',
                      style: Theme.of(context).textTheme.headline6,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Text(movie.overview),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Video',
                      style: Theme.of(context).textTheme.headline6,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      child: InkWell(
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Image.network(movie.videoThumbnail),
                            CircleAvatar(
                              child: IconButton(
                                icon: const Icon(Icons.play_arrow),
                                onPressed: () {},
                              ),
                            ),
                          ],
                        ),
                        onTap: () async {
                          final uri = Uri.parse(movie.video);
                          if (await canLaunchUrl(uri)) {
                            await launchUrl(uri);
                          }
                        },
                      ),
                    )
                  ],
                ),
              ),
              FutureBuilder(
                future: movie.getActors(),
                builder: (context, snapshot) {
                  if (snapshot.hasData) {
                    final actors = snapshot.requireData;
                    return Card(
                      color: Theme.of(context).colorScheme.primary,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(16),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                            child: Text(
                              'Diễn viên',
                              style: Theme.of(context).textTheme.headline6?.copyWith(color: Colors.white),
                            ),
                          ),
                          SizedBox(
                            height: MediaQuery.of(context).size.height / 2.2,
                            child: ListView.builder(
                              padding: const EdgeInsets.all(8),
                              scrollDirection: Axis.horizontal,
                              itemCount: actors.length,
                              itemBuilder: (context, index) {
                                final actor = actors.elementAt(index);
                                return InkWell(
                                  child: Card(
                                    color: Colors.transparent,
                                    shadowColor: Theme.of(context).colorScheme.primary,
                                    shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.vertical(
                                        bottom: Radius.circular(8),
                                      ),
                                    ),
                                    child: SizedBox(
                                      width: MediaQuery.of(context).size.width / 3,
                                      child: Column(
                                        children: [
                                          Image.network(
                                            actor.images.first,
                                          ),
                                          ListTile(
                                            title: Text(
                                              actor.name,
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(color: Theme.of(context).colorScheme.onPrimary),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  onTap: () => Navigator.pushNamed(context, '/actor', arguments: actor),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    );
                  }
                  return const Center(
                    child: CircularProgressIndicator(),
                  );
                },
              ),
              // Similar
              Container(
                margin: const EdgeInsets.symmetric(vertical: 8),
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(
                    Radius.circular(16),
                  ),
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage(
                      'https://e.khoahoc.tv/photos/image/2015/12/15/anh-dep-mua-dong-21.jpg',
                    ),
                  ),
                ),
                child: Column(
                  children: [
                    ListTile(
                      selected: true,
                      selectedColor: secondaryColor,
                      minLeadingWidth: 0,
                      title: Text(
                        AppRepository.translate(16),
                      ),
                      leading: const Icon(Icons.recommend),
                      trailing: TextButton(
                        onPressed: () async {
                          Navigator.pushNamed(
                            context,
                            '/movie',
                            arguments: await AppRepository.getAllMovies(),
                          );
                        },
                        child: Text(
                          AppRepository.translate(7),
                          style: TextStyle(color: secondaryColor),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height / 2.2,
                      child: FutureBuilder(
                        future: AppRepository.getAllMovies(),
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            final movies = snapshot.requireData.toList()
                              ..take(10)
                              ..shuffle();
                            return ListView.separated(
                              scrollDirection: Axis.horizontal,
                              padding: const EdgeInsets.all(8).copyWith(top: 0),
                              itemCount: movies.length,
                              itemBuilder: (context, index) {
                                final movie = movies.elementAt(index);
                                final rating = Random.secure().nextDouble();

                                return InkWell(
                                  child: SizedBox(
                                    width: MediaQuery.of(context).size.width / 3,
                                    child: Column(
                                      children: [
                                        Stack(
                                          children: [
                                            Image.network(
                                              movie.images.first,
                                            ),
                                            Positioned(
                                              left: 8,
                                              bottom: 8,
                                              child: CircleAvatar(
                                                child: Center(
                                                  child: Stack(
                                                    alignment: Alignment.center,
                                                    children: [
                                                      Text((rating * 100).toStringAsFixed(0)),
                                                      CircularProgressIndicator(
                                                        value: rating,
                                                        color: rating >= 0.5 ? Colors.greenAccent : Colors.yellow,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        ListTile(
                                          title: Text(
                                            movie.name,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(color: secondaryColor),
                                          ),
                                          subtitle: Text(
                                            '${movie.year}',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
                                );
                              },
                              separatorBuilder: (context, index) => const SizedBox(width: 8),
                            );
                          }
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
              // Poster
              Container(
                margin: const EdgeInsets.symmetric(vertical: 8),
                decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(
                    Radius.circular(16),
                  ),
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage(
                      movie.images.last,
                    ),
                  ),
                ),
                child: SizedBox(
                  height: MediaQuery.of(context).size.height / 3,
                  child: Center(
                    child: Card(
                      color: primaryColor,
                      shadowColor: Theme.of(context).colorScheme.primary,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.all(
                          Radius.circular(8),
                        ),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 4,
                        ),
                        child: Text(
                          AppRepository.translate(18),
                          style: Theme.of(context).textTheme.titleLarge?.copyWith(color: secondaryColor),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              // Recommend
              Container(
                margin: const EdgeInsets.symmetric(vertical: 8),
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(
                    Radius.circular(16),
                  ),
                  image: DecorationImage(
                    fit: BoxFit.cover,
                    image: NetworkImage(
                      'https://e.khoahoc.tv/photos/image/2015/12/15/anh-dep-mua-dong-21.jpg',
                    ),
                  ),
                ),
                child: Column(
                  children: [
                    ListTile(
                      selected: true,
                      selectedColor: secondaryColor,
                      minLeadingWidth: 0,
                      title: Text(
                        AppRepository.translate(5),
                      ),
                      leading: const Icon(Icons.recommend),
                      trailing: TextButton(
                        onPressed: () async {
                          Navigator.pushNamed(
                            context,
                            '/movie',
                            arguments: await AppRepository.getAllMovies(),
                          );
                        },
                        child: Text(
                          AppRepository.translate(7),
                          style: TextStyle(color: secondaryColor),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: MediaQuery.of(context).size.height / 2.2,
                      child: FutureBuilder(
                        future: AppRepository.getAllMovies(),
                        builder: (context, snapshot) {
                          if (snapshot.hasData) {
                            final movies = snapshot.requireData.toList()
                              ..take(10)
                              ..shuffle();
                            return ListView.separated(
                              scrollDirection: Axis.horizontal,
                              padding: const EdgeInsets.all(8).copyWith(top: 0),
                              itemCount: movies.length,
                              itemBuilder: (context, index) {
                                final movie = movies.elementAt(index);
                                final rating = Random.secure().nextDouble();

                                return InkWell(
                                  child: SizedBox(
                                    width: MediaQuery.of(context).size.width / 3,
                                    child: Column(
                                      children: [
                                        Stack(
                                          children: [
                                            Image.network(
                                              movie.images.first,
                                            ),
                                            Positioned(
                                              left: 8,
                                              bottom: 8,
                                              child: CircleAvatar(
                                                child: Center(
                                                  child: Stack(
                                                    alignment: Alignment.center,
                                                    children: [
                                                      Text((rating * 100).toStringAsFixed(0)),
                                                      CircularProgressIndicator(
                                                        value: rating,
                                                        color: rating >= 0.5 ? Colors.greenAccent : Colors.yellow,
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        ListTile(
                                          title: Text(
                                            movie.name,
                                            maxLines: 2,
                                            overflow: TextOverflow.ellipsis,
                                            style: TextStyle(color: secondaryColor),
                                          ),
                                          subtitle: Text(
                                            '${movie.year}',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  onTap: () => Navigator.pushNamed(context, '/movie/detail', arguments: movie),
                                );
                              },
                              separatorBuilder: (context, index) => const SizedBox(width: 8),
                            );
                          }
                          return const Center(
                            child: CircularProgressIndicator(),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
