class Category {
  final String id;
  final String name;

  const Category._({
    required this.id,
    required this.name,
  });

  factory Category.fromJson(String id, Map<String, dynamic> fields) {
    return Category._(
      id: id,
      name: fields['name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      id: {},
    };
  }
}
