import 'package:movie/app/repository.dart';
import 'package:movie/models/category.dart';

import 'actor.dart';

class Movie {
  final String id;
  final String name;
  final String video;
  final String overview;
  final int time;
  final int year;
  final int budget;
  final int revenue;
  final Iterable<String> images;

  dynamic _actorIds;
  dynamic _categoryIds;

  Movie._({
    required this.id,
    required this.name,
    required this.video,
    required this.overview,
    required this.time,
    required this.year,
    required this.budget,
    required this.revenue,
    required this.images,
  });

  factory Movie.fromJson(String id, Map<String, dynamic> fields) {
    return Movie._(
      id: id,
      name: fields['name'],
      video: fields['video'],
      overview: fields['overview'],
      time: int.tryParse(fields['time'].toString()) ?? 0,
      year: int.tryParse(fields['year'].toString()) ?? 0,
      budget: int.tryParse(fields['budget'].toString()) ?? 0,
      revenue: int.tryParse(fields['revenue'].toString()) ?? 0,
      images: List<String>.from(fields['images']),
    )
      .._actorIds = List<String>.from(fields['actor_ids'] ?? [])
      .._categoryIds = List<String>.from(fields['category_ids'] ?? []);
  }

  Map<String, dynamic> toJson() {
    return {
      id: {},
    };
  }

  String get videoThumbnail => 'https://i.ytimg.com/vi/${video.split('/').last}/hq720.jpg';

  Future<Iterable<Actor>> getActors() async {
    if (_actorIds is Iterable<Actor>) return _actorIds;
    final actors = await AppRepository.getAllActors();
    final actorIds = _actorIds as Iterable<String>;
    return _actorIds = actors.where((actor) => actorIds.contains(actor.id));
  }

  Future<Iterable<Category>> getCategories() async {
    if (_categoryIds is Iterable<Category>) return _categoryIds;
    final categories = await AppRepository.getAllCategories();
    final categoryIds = _categoryIds as Iterable<String>;
    return _categoryIds = categories.where((category) => categoryIds.contains(category.id));
  }
}
