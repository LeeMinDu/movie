import 'package:movie/app/repository.dart';

import 'movie.dart';

class Actor {
  final String id;
  final String name;
  final String bio;
  final bool gender;
  final String birthday;
  final Iterable<String> images;

  const Actor._({
    required this.id,
    required this.name,
    required this.bio,
    required this.gender,
    required this.birthday,
    required this.images,
  });

  factory Actor.fromJson(String id, Map<String, dynamic> fields) {
    return Actor._(
      id: id,
      name: fields['name'],
      bio: fields['bio'],
      gender: fields['gender'],
      birthday: fields['birthday'],
      images: List.from(fields['images']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      id: {
        'name': name,
        'bio': bio,
        'gender': gender,
        'birthday': birthday,
        'images': images,
      }
    };
  }

  Future<Iterable<Movie>> getMovies() async {
    final actingMovies = <Movie>[];
    final allMovies = await AppRepository.getAllMovies();
    for (final movie in allMovies) {
      final actors = await movie.getActors();
      if (actors.any((actor) => actor.id == id)) {
        actingMovies.add(movie);
      }
    }
    return actingMovies;
  }
}
