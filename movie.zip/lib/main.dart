import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'app/repository.dart';
import '/models/actor.dart';
import 'firebase_options.dart';
import 'models/movie.dart';
import 'pages/actor_page.dart';
import 'pages/main/main_page.dart';
import 'pages/movie/movie_detail_page.dart';
import 'pages/movie/movie_list_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await AppRepository.initialise();
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: createMaterialColor(
          const Color(0xff082444),
        ),
        brightness: await AppRepository.getTheme() ? Brightness.light : Brightness.dark,
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/actor':
            return MaterialPageRoute(
              builder: (context) => ActorPage(settings.arguments as Actor),
            );
          case '/movie':
            final args = settings.arguments as Map<String, dynamic>;
            return MaterialPageRoute(
              builder: (context) => MovieListPage(
                args['movies'],
                title: args['title'],
              ),
            );
          case '/movie/detail':
            return MaterialPageRoute(
              builder: (context) => MovieDetailPage(settings.arguments as Movie),
            );
        }
        return MaterialPageRoute(
          builder: (context) => const MainPage(),
        );
      },
    ),
  );
}

MaterialColor createMaterialColor(Color color) {
  List strengths = <double>[.05];
  final swatch = <int, Color>{};
  final int r = color.red, g = color.green, b = color.blue;

  for (int i = 1; i < 10; i++) {
    strengths.add(0.1 * i);
  }
  for (var strength in strengths) {
    final double ds = 0.5 - strength;
    swatch[(strength * 1000).round()] = Color.fromRGBO(
      r + ((ds < 0 ? r : (255 - r)) * ds).round(),
      g + ((ds < 0 ? g : (255 - g)) * ds).round(),
      b + ((ds < 0 ? b : (255 - b)) * ds).round(),
      1,
    );
  }
  return MaterialColor(color.value, swatch);
}
